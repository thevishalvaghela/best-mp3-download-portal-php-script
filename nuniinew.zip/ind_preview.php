<?php
$ind_info = ''.$FOLDER.''.$FILE[$i]['name'].'.'.$FILE[$i]['ext'].'';
if ($FILE[$i]['ext'] == nth OR $FILE[$i]['ext'] == thm) {  echo '<img src="/theme.php?file='.$ind_info.'" width="70" height="70" alt="'.$FILE[$i]['name'].'" class="border_4">'; } elseif ($FILE[$i]['ext'] == jar) {  echo '<img src="/jar.php?file='.$ind_info.'" width="70" height="70" alt="'.$FILE[$i]['name'].'" class="border_4">'; }
elseif($FILE[$i]['thumbext'] == '')
{
if($THUMB == '')
echo '<img src="'.BASE_PATH.'image/'.$FILE[$i]['ext'].'.png" alt="'.$FILE[$i]['name'].'" width="70" height="70" class="border_4">';
else
echo '<img src="'.BASE_PATH.'folderthumb/'.$THUMB.'" alt="'.$FILE[$i]['name'].'" width="70" height="70" class="border_4"> ';
}
else
echo '<img src="'.BASE_PATH.$FOLDER.'thumb-'.$FILE[$i]['dname'].'.'.$FILE[$i]['thumbext'].'" width="70" height="70" alt="'.$FILE[$i]['name'].'" class="border_4"> ';
?>
