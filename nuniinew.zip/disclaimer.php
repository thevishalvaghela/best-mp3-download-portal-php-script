<?php

print '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
<title>Disclaimer </title>';
echo '<link href="/css/style.css" rel="stylesheet" style="text/css"></head><body>';
print '<div class="logo"><center><img src="/image/wapkahostlogo.png" width="250" height="80" alt="logo"/></center></div><br/>';
print '<h2><b>Disclaimer</b></h2><br>
<b>
<div class="updateRow">

&raquo; 1.This is a promotional website only, All the downloadable content provided on this site (All materials) is for testing/promotion purposes only.All files placed here are for introducing purpose.</div>

<div class="updateRow">
&raquo; 2.We highly ENCOURAGE users to BUY the CDs or DVDs of the movie or the music they like.Please, buy original Songs/contents from author or developer site!</div>
<div class="updateRow">

&raquo; 3.If you Do not agree to all the terms, please disconnect from this site now itself.</div>

<div class="updateRow">

&raquo; 4.By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</div>

<div class="updateRow">

&raquo; 5.All files found on this site have been collected from various sources across the web and are believed to be in the "public domain".</div>

<div class="updateRow">

&raquo; 6.All the logos and stuff are the property of their respective owners.</div>

<div class="updateRow">

&raquo; 7.You should DELETE IT(data) within 24 hours and make a point to buy the original CD or DVD from a local or online store. </div>
<div class="updateRow">
&raquo; 8.If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, please contact us immediately and we will delete it!</div></b>


<h2><b>Privacy Statement</b></h2><br>

<b><div class="updateRow">

&raquo; Site has created this privacy statement in order to demonstrate our firm commitment to privacy. 
The following discloses the information gathering and dissemination practices for 
this Web/wap site  </div>

<div class="updateRow">

&raquo; Third Party Cookies In the course of serving advertisements to this site, 
our third-party advertiser may place or recognize a unique "cookie" on your browser.</div>

<div class="updateRow">

&raquo; We use an outside ad company to display ads on our site. 
These ads may contain cookies. While we use cookies in other parts of our site, 
cookies received with banner ads are collected by our ad company, and we do not 
have access to this information.Some customer data is shared with the advertising companies.</div>

<div class="updateRow">

&raquo; This Site contains links of other sites on the internet. 
We are not responsible for the privacy practices or the content of web sites we link to. 
We do make an effort to avoid linking to known "adult" and "porn" sites. 
This is a family web site.</div>

<div class="updateRow">

&raquo; To the maximum extent permitted by applicable law, we reserve the right to change or 
replace this Privacy Policy at any time and from time to time without prior notice to or 
the consent of any person. Any changes or replacement will be posted at this site.</div>

<div class="updateRow">

&raquo; If you have any questions about this privacy statement, 
or the practices of this site, Please feel free <a href="/extra/contact"><strong><font color="#ff0000">Contact Us</font></strong></a><br/>

</b>';


echo '<div class="search"><b><a class="siteLink" href="index.php"><font color="#ffffff">Home</font></a></b></div>';

echo '</body></html>';

?>

