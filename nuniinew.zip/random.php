﻿<?php
	include 'includes/config.php';
	 
       
$check = '';
   $TOTAL_FILE = 0;
   $rowsPerPage=15;
	
	$PATH = '';

	if($parentid != 0)
	{
			//from 41
$folddetail = $db->query('select * from category where id = '.$parentid.' order by kram desc', database::GET_ROW);
$seq =  $folddetail['pathc'];
$db->query("select pathc from category where id = ". $parentid, database::GET_FIELD);
$PATH = '» <a href="/">Home</a> ';
$PATH .= $seq;
}
          
if($parentid == 0)
{
$update_list = $db->query('select * from file order by rand() limit 6');
?>
<h2>Top Files</h2>
<?php
foreach($update_list as $field => $value)
{
  //$ddd = date('d-m-Y', strtotime($value['date']));
  ?>
<div class="catRow"><a href="<?=ToLink(BASE_PATH.'filedownload/'.$value['cid'].'/'.$value['id'].'/'.$value['name'].'.html');?>"><?=$value['name']?>.<?=$value['ext']?></a></div>
<?php
}
?>

<?
}
?>