<?php session_start();
	include 'includes/config.php';
	$location = 'http://' . $_SERVER['HTTP_HOST'] . str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']) . '/guestbook.php' ;

        //if(isset($_POST["captcha"]))
if($_SESSION["captcha"]==$_POST["captcha"])
{
    //CAPTHCA is valid; proceed the message: save to database, send by e-mail ...
	//echo 'CAPTHCA is valid; proceed the message';
	if(!isValidEmail($_POST['email']))
	{
		header("location: $location?errid=3");
		exit;
	}	
		
	function countryCityFromIP($ipAddr)
	{
		//verify the IP address for the
		ip2long($ipAddr)== -1 || ip2long($ipAddr) === false ? trigger_error("Invalid IP", E_USER_ERROR) : "";
		
		//get the XML result from hostip.info
		if($xml = file_get_contents("http://api.hostip.info/?ip=".$ipAddr))
		{
			//get the country name inside the node <countryName> and </countryName>
			//assign the country name to the $ipDetail array
			preg_match("@<countryName>(.*?)</countryName>@si",$xml,$matches);
			$country=$matches[1];
		}
	//return the array containing city, country and country code
	return $country;
	}
		
	
	$IPDetail=countryCityFromIP($_SERVER['REMOTE_ADDR']);
	$name=$_POST['name'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
	$ip = $_SERVER['REMOTE_ADDR'];	
			
	
	$flag = $IPDetail;
	$find = array('<','>','[',']');
	$message= strip_tags(str_replace($find,'',$_POST['message']));
	$uAgent = $_SERVER['HTTP_USER_AGENT'];
	$uProfile = $_SERVER['HTTP_X_WAP_PROFILE'];
		
	$query = "Insert into guest_book values(
						NULL,
						'$name',
						'$mobile',
						'$email',
						'$message',
						'$ip',
						'$flag',
						'$uAgent',
						'$uProfile',
						CURRENT_TIMESTAMP
				)";
	
	$db->query($query);	

	header('location: '.$location);
}
else
{
    echo 'captch code error;';
        header('location: '.$location."?errid=4");
}

?>
