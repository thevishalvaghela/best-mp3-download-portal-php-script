<?php
extension_loaded('ffmpeg') or 
die('ERROR IN LOADING FFMPEG EXTENSION');
echo "EXTENSION LOADED SUCESSFULLY";
?>