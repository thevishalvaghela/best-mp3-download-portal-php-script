<html><head><title>AutoIndex installer by Vishal S Baghela</title>
<style>h4 {color:white;background-color: black;
padding: 3px;text-align:center;}
</style></head>
<body><h4>Filmyundu.Com AUTOINDEX INSTALLER </h4>
<?php
if($_POST){

$fp = fopen('includes/db_details.php','w');
$content = '<?php $db_host = "'.$_POST['host'].'";
$db_user = "'.$_POST['user'].'";
$db_pass = "'.$_POST['pass'].'";
$db_name = "'.$_POST['name'].'";
// Calling the object with a database selected
$db = new database($db_host,$db_user,$db_pass,$db_name); ?>';
if(!fwrite($fp,trim($content)))
$error = 1;
fclose($fp);
$fp2 = fopen('includes/path.php','w');
$content2 = '<?php define("BASE_PATH","'.$_POST['siteurl'].'");
define("SITENAME","'.$_POST['sitename'].'"); ?>';
if(!fwrite($fp2,trim($content2)))
$error = 1;
fclose($fp2);
include "includes/connection.php";
$db = new database($db_host,$db_user,$db_pass,$db_name);
if(!$db->query("CREATE TABLE IF NOT EXISTS `admin` (`id` smallint(6) NOT NULL auto_increment,`username` varchar(255) NOT NULL,`password` varchar(255) NOT NULL,`email` varchar(255) NOT NULL,`sitename` varchar(255) NOT NULL,`filepostfix` varchar(50) NOT NULL,`title` text NOT NULL,`thumbw` int(3) NOT NULL,`thumbh` int(3) NOT NULL,`set` varchar(255) NOT NULL,`dthumbw` int(3) NOT NULL,`dthumbh` int(3) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;"))	$error = 1;
if(!$db->query("INSERT INTO `admin` (`id`, `username`, `password`, `email`, `sitename`, `filepostfix`, `title`, `thumbw`, `thumbh`, `set`, `dthumbw`, `dthumbh`) VALUES(1, 'filmy@admin', 'filmy@admin', 'vishalsbaghela@gmail.com', 'FilmyMundu.Com', '-FilmyMundu.Com', 'Welcome to FilmyMundu.Com', 350, 100, 'aHR0cDovL2Z1bGwybW9iLnRrLw==', 50, 60);"))	$error = 1;



if(!$db->query("CREATE TABLE IF NOT EXISTS `admin_setting` (`id` double NOT NULL auto_increment,`name` varchar(255) collate latin1_general_ci default NULL,`value` varchar(255) collate latin1_general_ci default NULL,`adminsetting_id` double NOT NULL default '0',PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;"))	$error = 1;
if(!$db->query("CREATE TABLE IF NOT EXISTS `category` (`id` int(11) NOT NULL auto_increment,`parentid` double NOT NULL,`name` varchar(256) NOT NULL,`active` tinyint(1) NOT NULL,`path` text NOT NULL,`pathc` text NOT NULL,`totalitem` double NOT NULL,`folder` text NOT NULL,`newitemtag` tinyint(1) NOT NULL,`updateitemtag` tinyint(1) NOT NULL,`subcate` tinyint(1) NOT NULL,`date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,`clink` text NOT NULL,`des` text NOT NULL,`thumb` text NOT NULL,`kram` double NOT NULL,`sub` text NOT NULL,PRIMARY KEY  (`id`),KEY `id_index` (`id`),KEY `date_index` (`date`),KEY `parentid_index` (`parentid`),KEY `kramindex` (`kram`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;


if(!$db->query("CREATE TABLE IF NOT EXISTS `file` (`id` double NOT NULL auto_increment,`name` text NOT NULL,`dname` text NOT NULL,`cid` double NOT NULL,`ext` varchar(5) NOT NULL,`thumbext` varchar(5) NOT NULL,`size` varchar(10) NOT NULL,`desc` text NOT NULL,`download` double NOT NULL,`view` double NOT NULL,`newtag` tinyint(1) NOT NULL,`imagetype` tinyint(1) NOT NULL,`kram` int(11) NOT NULL,PRIMARY KEY  (`id`),KEY `id_index` (`id`),KEY `download_index` (`download`),KEY `kramindex` (`kram`),KEY `cidindex` (`cid`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;

if(!$db->query("CREATE TABLE IF NOT EXISTS `download_record` (`id` double NOT NULL auto_increment,`fileid` double NOT NULL,`downloads` double NOT NULL,`date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,PRIMARY KEY  (`id`),KEY `id_index` (`id`),KEY `download_index` (`downloads`),KEY `fileidindex` (`fileid`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;

if(!$db->query("CREATE TABLE IF NOT EXISTS `guest_book` (`id` double NOT NULL auto_increment,`name` varchar(255) collate utf8_unicode_ci NOT NULL,`mobile` varchar(10) collate utf8_unicode_ci NOT NULL,`email` varchar(255) collate utf8_unicode_ci NOT NULL,`message` varchar(255) collate utf8_unicode_ci NOT NULL,`ip` varchar(17) collate utf8_unicode_ci NOT NULL,`flag` varchar(100) collate utf8_unicode_ci NOT NULL,`uagent` varchar(255) collate utf8_unicode_ci NOT NULL,`uprofile` varchar(255) collate utf8_unicode_ci NOT NULL,`date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;"))	$error = 1;
if(!$db->query("CREATE TABLE IF NOT EXISTS `update` (`id` double NOT NULL auto_increment,`name` text NOT NULL,`link` text NOT NULL,`home` tinyint(1) NOT NULL,`date` datetime NOT NULL,PRIMARY KEY  (`id`)) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;"))	$error = 1;
if($error){ echo "Some error camed up. Check /includes/db_details.php is writable or not.";
} else {echo "<h1>Installation Complete</h1>
<meta http-equiv='refresh' content='5; url=index.php'>";

// @unlink(__FILE__);
}
}else{
@chmod("includes/db_details.php",0666);

echo "<form action='?' method='post'>

Database Host<br/><input type='text' name='host' value='localhost'><br/>
Database User<br/><input type='text' name='user'><br/>
Database Password<br/><input type='text' name='pass'><br/>
Database Name<br/><input type='text' name='name'><br/>Site Url (put in end / )<br/><input type='text' name='siteurl'><br/>Site Name<br/><input type='text' name='sitename'><br/><h4>Admin Details</h4>Username: filmy@admin<br/>Password: filmy@admin<br/><input type='submit' value='Install'>
</form>";
}
?>
<h4>FilmyMundu.Com<br/>By Vishal S Baghela</h4></body></html>
