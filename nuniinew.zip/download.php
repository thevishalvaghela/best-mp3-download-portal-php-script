<?php

include("includes/connection.php");
include("includes/path.php");
include("includes/function.php");

$headset = $db->query('select filepostfix from  admin where id = 1', database::GET_FIELD);

define('POSTFIX', $headset);

$id = $_GET['id'];

if ($id != '') {
    $db->query('update file set view = view + 1 where id = ' . $id);
}

$kk = $db->query('select * from file where id = ' . $id, database::GET_ROW);

if ($kk['imagetype'] == 1 && $kk['ext'] != 'gif') {
    include 'function.resize.php';

    $size = explode('x', $_GET['size']);

    if ($id == '')
        header('location: ' . BASE_PATH);

    $folder = $db->query('select folder from category where id = ' . $kk['cid'], database::GET_FIELD);

    $file = $folder . $kk['dname'] . '.' . $kk['ext'];
$filename = $kk['name'] .$size[0].'x'.$size[1] . POSTFIX . '.' . $kk['ext'];

    if ($size[0] != '') {
        $settings = array('w' => $size[0], 'h' => $size[1], 'newname' => $filename);
        $file = BASE_PATH . resize($file, $settings);
    }
    else
        $file = BASE_PATH . $file;


    //$file = 'cache_img/Naturel 02 (21)-mirchifun.com.jpg_w240_h320.jpg';
    $file = str_replace(BASE_PATH, '', $file);
    //$file = str_replace('http://www.mirchifun.com/', '', $file);
    $filename = str_replace(' ', '-', $filename);
    header("Content-type: application/octet-stream");
    header("Content-Transfer-Encoding: Binary");
    //header("Content-length: ".filesize($file));
    header("Content-disposition: attachment; filename=" . $filename);
    readfile($file);
    
} else {
    if ($id == '')
        header('location: ' . BASE_PATH);
    $folder = $db->query('select folder from category where id = ' . $kk['cid'], database::GET_FIELD);

    $file = $kk['dname'] . '.' . $kk['ext'];
    $filename = $kk['name'] . POSTFIX . '.' . $kk['ext'];
    //$_GET['f'] = $file;

    header("location: " . BASE_PATH . "$folder$file");
    exit;
    //---------------------------
    // this is a relative path from this file to the
    // directory where the download files are stored.

    /*
      //$path='/home5/ayudevel/public_html/wap/'.$folder;
      // Add headers
      header('Content-Description: File Transfer');
      header('Content-Type: application/octet-stream');
      header('Content-Disposition: attachment; filename='.$filename);
      header('Content-Transfer-Encoding: binary');
      header('Expires: 0');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Pragma: public');
      header('Content-Length: ' . filesize($path.$file));

      // Flush
      ob_clean();
      flush();

      // Output file
      readfile($path.$file);
     */
}
?>
<?php $db->disconnect();
exit; ?>