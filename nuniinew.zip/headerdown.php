<?php
/*
// seconds, minutes, hours, days
$expires = 60*60*24*14;
header("Pragma: private");
header("Cache-Control: maxage=".$expires);
header('Expires: ' . gmdate('D, d M Y H:i:s', time()+$expires) . ' GMT');
header('Content-type: text/html; charset=utf-8'); */
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
$if = $_GET['id'];
$getfil = $db->query('select * from file where id = '.$if, database::GET_ROW);
$parentid = $getfil['cid'];
$foq = $db->query("select id as pid,folder,name as catname,name,thumb,pathc from category where id = ".$parentid, database::GET_ROW);
$cat = $foq['name'];
$typ = $getfil['ext'];
$nname = ucwords($nname);
?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="title" content="Free Download <?=$nname?> . <?=$typ?> - <?=$cat?> " />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />

<title>

<?php
echo $nname;
echo '.';
echo $typ;
echo ' - ';

echo $cat;
echo ' - Free Download ::';
echo ' Latest Mp3 BollyWood Songs, GAmes, themes, wallpaper,video, album Songs ::';
?>
</title>

<link rel="shortcut icon" href="<?=BASE_PATH?>favicon.ico" />
<link rel="stylesheet" href="/css/style.css" type="text/css"/>
</head><body><div class="logo"><a href="<?=BASE_PATH?>"><img src="/image/nunihostlogo.png" alt="logo" width="250" /></a></div>


<div class='search'>
<form method='get' action='<?=BASE_PATH?>search.php'>
Search File :
<input id='search' size='20' type='text' name='search' value="<?=$search?>">
<select name="type">
<option value='' <?php if($type == 'all') echo 'selected'; ?>>All</option>
<option value='3gp' <?php if($type == '3gp') echo 'selected'; ?> >3gp</option>
<option value='jpg' <?php if($type == 'jpg') echo 'selected'; ?>>jpg</option>
<option value='gif' <?php if($type == 'gif') echo 'selected'; ?>>gif</option>
<option value='mp3' <?php if($type == 'mp3') echo 'selected'; ?>>mp3</option>
<option value='avi' <?php if($type == 'avi') echo 'selected'; ?>>avi</option>
<option value='mp4' <?php if($type == 'mp4') echo 'selected'; ?>>mp4</option>
<option value='jar' <?php if($type == 'jar') echo 'selected'; ?>>jar</option>
<option value='sis' <?php if($type == 'sis') echo 'selected'; ?>>sis</option>
<option value='sisx' <?php if($type == 'sisx') echo 'selected'; ?>>sisx</option>
<option value='nth' <?php if($type == 'nth') echo 'selected'; ?>>nth</option>
<option value='exe' <?php if($type == 'exe') echo 'selected'; ?>>exe</option>
<option value='pdf' <?php if($type == 'pdf') echo 'selected'; ?>>pdf</option>
</select>
<input value='Search' type='submit' name='searchnow'>
</form>
</div>

<?=$LOGO?>
<center>
<?php
if(strstr(strtolower($agent_c),'windows'))
$agent_ext = '.pdv';
else
$agent_ext = '.adv';

if($LOGO != '')
include 'a'.$agent_ext;
else
include 'd'.$agent_ext;
?>
</center>