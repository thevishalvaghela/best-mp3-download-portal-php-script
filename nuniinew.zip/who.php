<?php
/*
	// seconds, minutes, hours, days
	$expires = 60*60*24*14;
	header("Pragma: private");
	header("Cache-Control: maxage=".$expires);
	header('Expires: ' . gmdate('D, d M Y H:i:s', time()+$expires) . ' GMT');
	header('Content-type: text/html; charset=utf-8'); */

?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>
    	DjSongMix.Com :: 
		<?php
			if($NTITLE != '')
				echo $NTITLE
		?>
        Free Mobile Ringtones games themes dj songs Love Old Dj Collection Bollywood movie songs download, Love Old Dj Collection   Movie mp3, New Dj Collection dJ mix songs, Free Softwares Dj Collection   Songs, Love Old Dj Collection mp3 songs free download, Bollywood videos, holi mp3, animation , Song Free Download,Full Video Song HD MP4 - 3GP Download

	</title>

	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="language" content="en" />
	<meta name="description" content="<?=str_replace('-',' ',$nname)?> - download video 3gp and mp4 for mobile , Love Old Dj Collection marathi movie songs download, Love Old Dj Collection   Movie mp3, Love Old Dj Collection dJ mix songs, Love Old Dj Collection   Songs, Love Old Dj Collection mp3 songs free download, Love Old Dj Collection video songs, Song Free Download,Full Video Song HD MP4 - 3GP Download
" />
	<meta name="keywords" content="<?=str_replace('-',' ',$nname)?> ,3gp, mp4, bhojpuri movie songs download, indian movies   Movie mp3, Love Old Dj Collection dJ mix songs, bollywood mp3 Collection   Songs, bhojpuriya mp3 songs free download, Love Old Dj Collection video songs, Song Free Download,Full Video Song HD MP4 - 3GP Download
,movie, music, video , wallpaper" />
	<meta name="robots" content="index, follow" />
       <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;"/>
       <meta name="MobileOptimized" content="width"/>
       <meta name="HandheldFriendly" content="true"/>
	<link rel="shortcut icon" href="/image/favicon.ico" />
	<link rel="stylesheet" href="/css/style.css" type="text/css" />
	<link rel="stylesheet" href="/css/paging.css" type="text/css" />
        
</head>
</head><body>
<div align="center" class="logo"><img src="/image/wapkahostlogo.png" alt="logo" width='200' />
</div> 




<body>

<h2>Online Users</h2>
<?
echo "<div class='title'><b>Online Users</b></div>";
$data = file('online1.dat');
echo '';
echo '';
foreach($data as $val)
{
$ex = explode('::', $val);
$ex2 = explode(' ', $ex[0]);
$i++;
echo "<div class='line'><b>$i. </b>$ex2[0]<br/><b>IP:</b> $ex[1]</div>";
}
echo '<div class="line"><a href="index.php">&#187; Home</a></div>';


?>

<center>
Online : <a href="who.php"><?php include 'online.php' ; ?></a> Users</div>
<div align="Center">Created by :- <a href="http://wapkahost.com"  target="_blank"><b>WapkaHost.Com</b></a></div></div>
</center>