<?

print '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>

<title>Terms and Conditons :: AllDjMaza.Com</title>';

echo '<link href="http://AllDjMaza.Com/css/wap.css" rel="stylesheet" style="text/css"></head><body>';

print '<div class="logo"><center><img src="http://AllDjMaza.Com/logo.png" width="250" height="80" alt="logo"/></center></div><br/>';



print '<h2><b>Terms and Conditons</b></h2><br>

<b><div class="updateRow">
&raquo;  Everything is FREE when you download from this Mobile site. 
However, charges still applies by your Mobile/Internet service provider. 
We are not responsible for your operator data transfer charges for inquiry contact your ISP.<br><br></div>

<div class="updateRow">

&raquo; You may keep a downloaded anything(songs, apps, games, images, tones, etc) on your mobile 
phone for only 24-hours. Once that 24-hour period expires, you must either DELETE it 
(apps, games, images, tones, etc.) OR PURCHASE it through the rightful owner/publisher 
of the content, which will give you the rights to keep the file on your mobile phone, 
or ANY STOEAGE MEDIUM.You CANNOT SELL any of the apps, games, images, tones, etc. to 
anyone in any way. This site is created for individuals who are WAP enthusiasts or hobbyists only.<br><br></div>

<div class="updateRow">

&raquo; AllDjMaza.Com AND THIS SITE PARTNERS holds NO 
responsibility for anything that happens to you or to your mobile phone, wireless device, 
computer or any storage medium at anytime.
&raquo; If you enter this site and not agreeing to these terms means you are violating 
code 431.322.12 of the Internet Privacy Act of 1995 and that means that you can NOT 
threaten any person(s) or company storing these files, can not prosecute any person(s) 
affiliated with this page which includes family, friends or individuals who run or 
enter this web site.<br><br></div>

<div class="updateRow">

&raquo; By accessing, downloading or viewing any of these files, you agree to all these terms. 
If you do not agree to all the terms, please disconnect from this site now. 
By remaining at this site, you affirm your understanding and compliance of 
the above disclaimer and absolve this site of any responsibility henceforth.<br><br></div></b>






<br><br></b>';


echo '<div class="search"><b><a class="siteLink" href="http://AllDjMaza.Com"><font color="RED"> AllDjMaza.Com</font></a></b></div>';

echo '</body></html>';

?>
