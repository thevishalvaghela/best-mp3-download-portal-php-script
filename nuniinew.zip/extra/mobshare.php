<div align="center"><div id="fb-root"></div> <script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_US/all.js#xfbml=1"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script><div class="fb-like" data-href="https://www.facebook.com/wapkahost/" data-width="310" data-height="The pixel height of the plugin" data-colorscheme="light" data-layout="standard" data-action="like" data-show-faces="true" data-send="false"></div>




  
<div><iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2Fwapkahost%2F518827868225645&amp;width&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;share=true&amp;height=70" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:70px;" allowTransparency="true"></iframe></div>
 
