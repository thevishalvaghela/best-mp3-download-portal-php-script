<?php
include 'includes/config.php';
include 'headerdown.php';

$id = $_GET['id'];

$getfile = $db->query('select * from file where id = '.$id, database::GET_ROW);
$folq = $db->query("select id as pid,folder,name as catname,name,thumb,pathc from category where id = ".$parentid, database::GET_ROW);

?>
<h2>
Free Download <?=$getfile['name'].'.'.$getfile['ext']?>
</h2>
<?php
if($id != '')
{
$db->query('update file set download = download + 1 where id = '.$id);
}

$FOLDER = $folq['folder'];
//$DES =  $folddetail['des'];
$NAME = $folq['name'];
$THUMB = $folq['thumb'];

$RELATED_FILE = $db->query('select * from file where cid = '.$parentid.' and id != '.$id.' order by rand() limit 3');

if($parentid != 0)
{
//$seq = $db->query("select pathc from category where id = ".$parentid, database::GET_FIELD);
$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;'.$folq['pathc'];
}
echo '<!-- NuniHost.Com :: Display Download Files -->';

?>
<div class="tCenter">
<center><?php include 'l'.$agent_ext;?></center>
<?php include 'file_preview.php';

echo nl2br($getfile['desc']);
echo '<br />';
?>
<b>

<center><?php include 'g'.$agent_ext; ?></center>
<br/>
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/<?=$getfile['name']?>.html">Download :-  <font color="#069BE5"> <?=$getfile['name'].'.'.$getfile['ext']?> </font> </a>
<br/>

<center><?php include 'f'.$agent_ext; ?></center>
<?php
if($getfile['imagetype'] == 1)
{
if($getfile['thumbext'] != 'gif')
{
echo '<br />';
echo '<span class="dow_2">Select Your Screen Size:</span><br />';
?>
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/128x128/<?=$getfile['name']?>.html">128x128</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/128x160/<?=$getfile['name']?>.html">128x160</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/176x220/<?=$getfile['name']?>.html">176x220</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/220x176/<?=$getfile['name']?>.html">220x176</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/240x320/<?=$getfile['name']?>.html">240x320</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/320x240/<?=$getfile['name']?>.html">320x240</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/320x480/<?=$getfile['name']?>.html">320x480</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/360x640/<?=$getfile['name']?>.html">360x640</a>,
<a class="new_dow_text" rel="nofollow" href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/640x480/<?=$getfile['name']?>.html">640x480</a>
<br />
<?php
}
}
?>

<br/>
<center>
<div>
<object type="application/x-shockwave-flash" data="http://newmp3maza.com/player2.swf" width="200" height="20">
    <param name="movie" value="http://newmp3maza.com/player2.swf" />
    <param name="bgcolor" value="#ffffff" />
    <param name="FlashVars" value="mp3=<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/<?=$getfile['name']?>.html&amp;volume=75&amp;showstop=1&amp;showvolume=1" />
</object>
</div>	
</center>
<br/>

<center><span class='dow_2'>Share Music On Facebook ::</span>&nbsp; <b><span><a href='http://www.facebook.com/share.php?u=href="<?=BASE_PATH?>files/download/id/<?=$getfile['id']?>/<?=$getfile['name']?>.html' target='_blank'>Share</a></span></b><br /></center> 

<span class="dow_2">Size of file:</span>&nbsp; <span class="dow_1"> <font color="#069BE5"><?= getsize($getfile['size'])?></font></span><br />
<span class="dow_2">Downloaded:</span>&nbsp; <span class="dow_1"><font color="#069BE5"><?=$getfile['download']?> Time </font></span><br />
<span class="dow_2">Category:</span>&nbsp; <span class="dow_1"><a href="<?=BASE_PATH?>category/<?=$parentid?>/<?=$folq['catname']?>.html"><font color="#069BE5"><?=$folq['catname']?></font></a></span></div></b>


<br />
<table cellspacing="0">
<tbody>
<tr>
<td colspan="2">
<h3>Related Downloads</h3>
</td>
</tr>
<tr>
<td colspan="2">
<?php include 'm'.$agent_ext; ?>
</td>
</tr>
<?php
$l = 1;
$file_tot = count($RELATED_FILE);
for($i=0;$i<$file_tot;$i++)
{
if($l==1)
{
$l++;
$class = 'fl odd';
}
else
{
$l=1;
$class='fl even';
}

?>
<tr class="<?=$class?>">
<td class="tblimg">
<?php include 'rel_preview.php'; ?>
</td>
<td align="left">
<b><a class="new_link" href="<?=BASE_PATH?>filedownload/<?=$parentid?>/<?=$RELATED_FILE[$i]['id']?>/<?=$RELATED_FILE[$i]['name']?>.html"><?=$RELATED_FILE[$i]['name']?>.<?=$RELATED_FILE[$i]['ext']?></a></b><br/>
<span class="text11">[<?=getSize($RELATED_FILE[$i]['size'])?> ] &nbsp; | &nbsp; <?=$RELATED_FILE[$i]['download']?> Downloads</span>
</td>
</tr>
<?php
}
?>
</tbody>
</table>
<div class="advertisement">
<?php include 'n'.$agent_ext; ?>
</div>
<br />


<b>Tags: </b> <?=$getfile['name']?> Song download , <?=$getfile['name']?>  Full mp3 song download, <?=$getfile['name']?> Mp3 Song download 
,<?=$getfile['name']?>  All Mp3 Song Download ,song download in high quality



<div class="bt"></div>
<div class="path">
<?=$PATH?>
</div>
<?php
include 'footer.php';
?>
