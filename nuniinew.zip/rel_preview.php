<?php
$rel_info = ''.$FOLDER.''.$RELATED_FILE[$i]['name'].'.'.$RELATED_FILE[$i]['ext'].'';
if ($RELATED_FILE[$i]['ext'] == nth OR $RELATED_FILE[$i]['ext'] == thm) {  echo '<img src="/theme.php?file='.$rel_info.'" width="70" height="70" alt="'.$RELATED_FILE[$i]['name'].'" class="border_4">'; } elseif ($RELATED_FILE[$i]['ext'] == jar) {  echo '<img src="/jar.php?file='.$rel_info.'" width="70" height="70" alt="'.$RELATED_FILE[$i]['name'].'" class="border_4">'; }
elseif($RELATED_FILE[$i]['thumbext'] == '')
{
if($THUMB == '')
echo '<img src="'.BASE_PATH.'image/'.$RELATED_FILE[$i]['ext'].'.png" alt="'.$RELATED_FILE[$i]['name'].'" width="70" height="70" class="border_4">';
else
echo '<img src="'.BASE_PATH.'folderthumb/'.$THUMB.'" alt="'.$RELATED_FILE[$i]['name'].'" width="70" height="70" class="border_4"> ';
}
else
echo '<img src="'.BASE_PATH.$FOLDER.'thumb-'.$RELATED_FILE[$i]['dname'].'.'.$RELATED_FILE[$i]['thumbext'].'" width="70" height="70" alt="'.$RELATED_FILE[$i]['name'].'" class="border_4"> ';
?>
