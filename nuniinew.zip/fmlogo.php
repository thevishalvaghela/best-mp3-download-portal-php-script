<title>NuniHost.Com [ Logo Changer ] By Vishal S Vaghela</title>


<center><img src="/image/nunihostlogo.png" heaight="150" width="250"/></center>
 

<?php

 

$type = $_POST['type'];

$value = $_POST['valuex'];

$valuex = 20;

$valuey = 10;

$size = $_POST['size'];





if ( $value != '')

{ 

$valuex = $_POST['valuex'];

$valuey = $_POST['valuey'];

}



if ($_POST['type'] == 1)

{

unlink('image/nunihostlogo.png');

copy('../../image/nunihostlogo.jpg','image/nunihostlogo.png');

echo '<div class="valid_box">Default Image Now as Cover</div>';

}



if ($type == 0 )



{

$url = $_POST['url'];



}





if ($url != '')

{

$name = basename($url);       

$ext = pathinfo($url,PATHINFO_EXTENSION);

// to get extension        

$name2 = pathinfo($url,PATHINFO_FILENAME);

//file name without extension

}



$target_dir ="image/";

$target_file= "image/nunihostlogo.png"; 

$img = 'image';

$uploadOk =1;

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check if $uploadOk is set to 0 by an error

if ($uploadOk == 0) 

{echo "Sorry, your file was not uploaded.";

// if everything is ok, try to upload file

} 

else {if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) 

{

echo "<div class='valid_box'>The file<strong> ".basename( $_FILES["file"]["name"])." </strong>has been uploaded as logo.</div>"; } 

else {echo "";}}

if ($url != '' )

{



include("mp3_url.php");

echo "<div class='valid_box'>Url File <strong> $name2.$ext</strong> Copied Successfully</div>";



}

 if ($_POST['tag'] == 1 )

{

$text = 'NuniHost.Com';

$color = '#FFFFFF';

$font = 'arial.ttf';

$imgpath = 'image/nunihostlogo.png';

$angle = 0;

$offset_x = $valuex;

$offset_y = $valuey;

$drop_shadow = true;

$shadow_color = '#000000';

$mode = 1;

$images_folder = 'image/';

$destination_folder = 'image/';



include("../../includes/watermark_text.class.php");



// Image path

$imgpath = 'image/nunihostlogo.png';

// Where to save watermarked image

$imgdestpath = $imgpath;



// create class instance

$img = new Zubrag_watermark($imgpath);



// shadow params

$img->setShadow($drop_shadow, $shadow_color);

$font_size = $size;

// font params

$img->setFont($font, $font_size);



// Apply watermark

$img->ApplyWatermark($text, $color, $angle, $offset_x, $offset_y);



// Save on server

$img->SaveAsFile($imgdestpath);



// Output to browser

//$img->Output();



// release resources

$img->Free();

echo "<div class='valid_box'>Tag added Successfully</div>";

}

else echo '';



$target = 'image/nunihostlogo.png';

$newcopy = $target;

$w = 500;

$h = 500;

$thumbext = '.jpg';


 


?>



<h2><center>Change WapSite Logo</h2>

</center>

<img src="/image/nunihostlogo.png" height="90" width="300"/>

<form action="/fmlogo.php" enctype="multipart/form-data" method="post"> 

<filedset>

Select File: <br/><input name="file" type="file"/><br/><br/>

 <input name="submit" type="submit" value="Upload File"/></fieldset> </form>



<br/> 

        
           
<br/>

<h2>Devloped by NuniHost.Com Inc.  (Vishal S Vaghela)</h2>




<div>
<style type="text/css"> 

body{ max-width: 1000px; color:; border: 1px solid silver; background-color: white; font-family: Georgia, serif; font-size: 14px; /*max-width: 500px; */margin: 5px auto;} 
a:link,a:active{ color: blue; background-color:; text-decoration: none; font-size: 14px; } 
a:hover{ color: green; background-color: ; text-decoration: underline; font-family: Comic Sans Ms; font-size: 14px; } 
a:visited{ color: red; background-color: inherit; text-decoration: none; font-size: 14px; } 
div.upban { text-align:center; padding: 3px; background-color: #FF8C00; color: #ffffff; border-bottom: 1px dotted #999999; border-top: 1px dotted #999999; } 
div.counter { text-align:center; background-color:#99CC99; margin:0px } 
div.line{ color: inherit; background-color: inherit; border-top: 1px solid silver; } 
div.gap{ color: inherit; background-color: inherit; height: 0.5em; } 
div.download{ color: inherit; background-color: inherit; text-align: center; } 
.wapkahost { padding:5px; background::#ece8f6;   text-decoration: bold; border-bottom:2px solid #ddd;}
hr{ background-color:#ccc; border:medium none; height:1px; margin:2px 0; padding:0;}
h1, h2, h3{ 
background:#8466C8;
background: -moz-linear-gradient(center bottom, #8466C8 0%, #5D3CA6 100%); 
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#8466C8), color-stop(100%,#5D3CA6)); 
background: -webkit-linear-gradient(center bottom, #8466C8 0%, #5D3CA6 100%); 
font-size:110%; padding:5px; margin:0; color:#fff; text-shadow: 1px 1px 3px #555; box-shadow:0 -2px 2px #c8bbe6; text-align:center;}
.pgn { padding:5px 0; text-align:center;}
.pgn form{ padding-top:5px; }
.pgn a, .pgn span { padding:2px 5px; margin:0 1px; font-weight:bold; -moz-border-radius:5px; -webkit-border-radius:5px; }
.pgn a { border:1px solid #ccc; background:#f5f5f5; }
.pgn div { padding-top:5px; }
.pgn span,.pgn a:hover { border:1px solid #ccc; background:#ddd; color:#777;}


</style> 
</div>







