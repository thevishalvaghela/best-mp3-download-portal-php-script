<center>
<?php if($LOGO != '')
{
include 'b'.$agent_ext;
}
?>
</center>
<div class="catList" align="left">
<?php
if($parentid == 0)
{ include 'services.php'; } ?></div>
<center>
<?php
if($LOGO == '')
include 'e'.$agent_ext;
?>
 </div>
</center>
   
   <h2>
	<b><a class="siteLink" href="<?=BASE_PATH?>"> <font color="#ffffff"> &copy 2016 <?=SITENAME?> </font> </a>
     <br/><a href="<?=BASE_PATH?>disclaimer.php"><font color="#ffffff">Disclaimer</font></a> | <a href="<?=BASE_PATH?>extra/contact"><font color="#ffffff">Contact Us</font></a></b></h2>
  </h2>

<div align="Center">Created by :- <a href="http://nunihost.com/"  target="_blank"><b>NuniHost.Com</b></a></div></div>

<?php $db->disconnect(); ?>
</body></html>
