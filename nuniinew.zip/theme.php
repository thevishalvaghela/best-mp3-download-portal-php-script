<?php

$theme= strip_tags($_GET["file"]);

$W = 100;
$H = 100;

$name = ''.basename($theme).'.gif';

$namef = 'themedata/'.basename($theme).'.gif';

if(file_exists($namef)){
header('Location: '.$namef, true, 301);
exit;
}

$type=".".end(explode(".",$theme));

if($W AND $H)
{
$g_preview_image_w = $W;
$g_preview_image_h = $H;
}
else
{
$g_preview_image_w = 100; // width of the image
$g_preview_image_h = 100; // height if the image
}

if($type == '.nth'){
include 'lib/pclzip.lib.php';

$nth = &new PclZip($theme);
$content = $nth->extract(PCLZIP_OPT_BY_NAME,'theme_descriptor.xml',PCLZIP_OPT_EXTRACT_AS_STRING);

$teg = simplexml_load_string($content[0]['content'])->wallpaper['src'] or $teg = simplexml_load_string($content[0]['content'])->wallpaper['main_display_graphics'];
$image = $nth->extract(PCLZIP_OPT_BY_NAME, trim($teg), PCLZIP_OPT_EXTRACT_AS_STRING);

$im = array_reverse(explode('.',$teg));
$im = 'imageCreateFrom'.str_ireplace('jpg','jpeg',trim($im[0]));

file_put_contents($namef,$image[0]['content']);
$f = $im($namef);

$h = imagesy($f);
$w = imagesx($f);

$ratio = $w/$h;
if($g_preview_image_w/$g_preview_image_h > $ratio){
$g_preview_image_w = $g_preview_image_h*$ratio;
}
else{
$g_preview_image_h = $g_preview_image_w/$ratio;
}


$new = imagecreatetruecolor($g_preview_image_w, $g_preview_image_h);
imagecopyresampled($new, $f, 0, 0, 0, 0, $g_preview_image_w, $g_preview_image_h, $w, $h);

imageGif($new, $namef, 100);
}
elseif($type == '.thm'){
include 'lib/tar.php';

$thm = &new Archive_Tar($theme);
$deskside_file = $thm->extractInString('Theme.xml');
$load = simplexml_load_string($deskside_file)->Standby_image['Source'] or $load = simplexml_load_string($deskside_file)->Desktop_image['Source'] or $load = simplexml_load_string($deskside_file)->Desktop_image['Source'];
$image = $thm->extractInString(trim($load));

$im = array_reverse(explode('.',$load));
$im = 'imageCreateFrom'.str_ireplace('jpg','jpeg',trim($im[0]));

file_put_contents($namef,$image);
$f = $im($namef);

$h = imagesy($f);
$w = imagesx($f);

$ratio = $w/$h;
if($g_preview_image_w/$g_preview_image_h > $ratio){
$g_preview_image_w = $g_preview_image_h*$ratio;
}
else{
$g_preview_image_h = $g_preview_image_w/$ratio;
}


$new = imagecreatetruecolor($g_preview_image_w, $g_preview_image_h);
imagecopyresampled($new, $f, 0, 0, 0, 0, $g_preview_image_w, $g_preview_image_h, $w, $h);

imageGif($new, $namef, 100);
}


header('Location: '.$namef, true, 301);
?>
