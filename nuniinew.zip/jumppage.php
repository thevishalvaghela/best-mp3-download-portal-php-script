<?php
$htmlpage = $_GET['htmlpage'];
$pagelink = $_GET['pagelink'];
$page = $_GET['page'];
header("location: ".$pagelink.$page.$htmlpage."");
?>
