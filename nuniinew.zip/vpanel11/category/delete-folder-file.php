<?php
    unlink('../../folder/'.$_GET['name']);
    header('location: folderfile.php?id='.$_GET['id']);
?>

