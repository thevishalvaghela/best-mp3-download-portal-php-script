<?php

include '../header.php';

$type = $_POST['type'];

$value = $_POST['valuex'];

$valuex = 20;

$valuey = 10;

$size = $_POST['size'];





if ( $value != '')

{ 

$valuex = $_POST['valuex'];

$valuey = $_POST['valuey'];

}



if ($_POST['type'] == 1)

{

unlink('image/Wapkahost.jpg');

copy('../../image/Wapkahost.jpg','image/Wapkahost.jpg');

echo '<div class="valid_box">Default Image Now as Cover</div>';

}



if ($type == 0 )



{

$url = $_POST['url'];



}





if ($url != '')

{

$name = basename($url);       

$ext = pathinfo($url,PATHINFO_EXTENSION);

// to get extension        

$name2 = pathinfo($url,PATHINFO_FILENAME);

//file name without extension

}



$target_dir ="image/";

$target_file= "image/Wapkahost.jpg"; 

$img = 'image';

$uploadOk =1;

$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check if $uploadOk is set to 0 by an error

if ($uploadOk == 0) 

{echo "Sorry, your file was not uploaded.";

// if everything is ok, try to upload file

} 

else {if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) 

{

echo "<div class='valid_box'>The file<strong> ".basename( $_FILES["file"]["name"])." </strong>has been uploaded.</div>"; } 

else {echo "";}}

if ($url != '' )

{



include("mp3_url.php");

echo "<div class='valid_box'>Url File <strong> $name2.$ext</strong> Copied Successfully</div>";



}

 if ($_POST['tag'] == 1 )

{

$text = ''.SITENAME.'';

$color = '#FFFFFF';

$font = 'arial.ttf';

$imgpath = 'image/Wapkahost.jpg';

$angle = 0;

$offset_x = $valuex;

$offset_y = $valuey;

$drop_shadow = true;

$shadow_color = '#000000';

$mode = 1;

$images_folder = 'image/';

$destination_folder = 'image/';



include("../../includes/watermark_text.class.php");



// Image path

$imgpath = 'image/Wapkahost.jpg';

// Where to save watermarked image

$imgdestpath = $imgpath;



// create class instance

$img = new Zubrag_watermark($imgpath);



// shadow params

$img->setShadow($drop_shadow, $shadow_color);

$font_size = $size;

// font params

$img->setFont($font, $font_size);



// Apply watermark

$img->ApplyWatermark($text, $color, $angle, $offset_x, $offset_y);



// Save on server

$img->SaveAsFile($imgdestpath);



// Output to browser

//$img->Output();



// release resources

$img->Free();

echo "<div class='valid_box'>Tag added Successfully</div>";

}

else echo '';



$target = 'image/Wapkahost.jpg';

$newcopy = $target;

$w = 500;

$h = 500;

$thumbext = '.jpg';



img_resize($target, $newcopy, $w, $h, $thumbext);



?>



<h2><center>Change Mp3 Cover</h2>

</center>

<img src="<?=ADMIN_BASE_PATH?>category/image/Wapkahost.jpg" height="120px" width="120px"/>

<form action="<?=ADMIN_BASE_PATH?>category/mp3tag.php" enctype="multipart/form-data" method="post"> 

<filedset>

Select File: <br/><input name="file" type="file"/>

                               



<br/>

<label for="Url">Upload By Url:<br/></label><input type="text" name='url' />



<br/>

<label for="Tag"> Set Default Image? :</label><input type="checkbox" name='type' value='1' />



<br/>

<label for="Tag">Tag Image ? :</label><input type="checkbox" name='tag' value='1' />

<br/>

Tag Type:- 

<br/>

Value:

<label for="valuex">X</label><input type="text" name='valuex' size ="5" value="15" />

<label for="valuey">Y</label><input type="text" name='valuey' size="5" value="10"/>

<br/>

<label for="Size">Tag Size:</label><input type="text" name='size' value="20" size="5"/><br/>



 <input name="submit" type="submit" value="Upload File"/></fieldset> </form>



<?php include '../footer.php'; ?>