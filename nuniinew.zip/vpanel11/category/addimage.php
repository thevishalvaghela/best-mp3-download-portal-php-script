<?php include '../header.php'; ?>
<?php
if ($_GET['id'] == '')
    exit;

$id = $_REQUEST['id'];
$LAST = $_REQUEST['last'];

if ($LAST != '') {
    //echo '<br />';
    ?>
        <div class="valid_box">
    <?php echo 'Last Uploaded File <strong> ' . $LAST .'</strong>' ; ?>
        </div>
    <?php
}
?>

<h2></h2>
<a href="index.php?pid=<?= $id ?>" class="bt_blue"><span class="bt_blue_lft"></span><strong>&laquo; Go Back To File list</strong><span class="bt_blue_r"></span></a>
<h2>&nbsp;&nbsp; Add Image</h2>
<div align="left">
    <form action="addimage_db.php" method="post" enctype="multipart/form-data" class="niceform">
        <fieldset>
            <dl>
                <dt><label for="Upload from url">Upload from url:</label></dt>
                <dd><input type="text" name="url" id="" size="54" /></dd>
            </dl>
            <dl>
                <dt></dt>
                <dd><label for="or">Or</label></dd>
            </dl>
            <dl>
                <dt><label for="Upload from url">File to upload:</label></dt>
                <dd><input type="file" name="file" /></dd>
            </dl>
            <dl>
                <dt><label for="File name">File name:</label></dt>
                <dd><input type="text" name="name" id="" size="54" /></dd>
            </dl>
            <dl>
                <dt><label for="New item tag">New Item Tag:</label></dt>
                <dd>
                    <input type="checkbox" name="newtag" value="1" checked="checked" />
                </dd>
            </dl>
            <dl>
                <dt><label for="Description">Description:</label></dt>
                <dd><textarea name="desc" rows="10" cols="50"><?= $n['desc'] ?></textarea></dd>
            </dl>
            <input type="hidden" name="cid" value="<?= $id ?>" />
            <dl class="submit">
                <dt></dt>
                <dd>
                    <input type="submit" name="submit" id="submit" value="Submit" />
                </dd>
            </dl>
        </fieldset>
    </form>
</div>
<?php include $adminfoldername.'/footer.php'; ?>