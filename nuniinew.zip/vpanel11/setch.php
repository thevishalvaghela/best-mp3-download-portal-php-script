<?php
include("includes/admin-config.php");
$files = glob('/home/don/public_html/cache/*'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}
header( 'refresh: 3; url='.ADMIN_BASE_PATH);
echo '<h1>Clear Cache successfully......Wait 3 second!</h1>';
?>