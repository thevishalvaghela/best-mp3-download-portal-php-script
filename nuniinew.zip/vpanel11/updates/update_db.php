<?php

include("../includes/admin-config.php");

$name = $_REQUEST['name'];
$link = $_REQUEST['link'];

$newid = $db->query("insert into `update` (name,link,home,date) values('$name','$link',1,now())");

header("location: index.php?errid=13");
?>