<?php

include("../includes/admin-config.php");

$page = $_GET['page'];
if ($_GET['action'] == 'on')
    $update = 'update `update` set home = 1 where id = ' . $_REQUEST['id'];
elseif ($_GET['action'] == 'off')
    $update = 'update `update` set home = 0 where id = ' . $_REQUEST['id'];
$db->query($update);

if ($page != 0)
    header("location: index.php?errid=15&page=$page");
else
    header("location: index.php?errid=15");
?>