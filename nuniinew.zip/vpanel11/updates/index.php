<?php include '../header.php'; ?>
<script src="<?php echo BASE_PATH?>js/validation.js"></script>
<script language="javascript" >
    var compulsory = new Array('name');
    var dispError = new Array('Name !');
</script>
<h2></h2>
<h2 style="background-color:#0099CC;">&nbsp;&nbsp;<a style="color: #FFFFFF" class="menuitem submenuheader" href="">Add Updates &nbsp;</a></h2>
<div class="submenu">
    <div align="left">
        <form action="update_db.php" method="post" enctype="multipart/form-data" onsubmit="return chkfrm(compulsory,dispError,this)" class="niceform">
            <fieldset>
                <dl>
                    <dt><label for="Title">Title:</label></dt>
                    <dd><input type="text" name="name" id="" size="54" /></dd>
                </dl>
                <dl>
                    <dt><label for="Upload from url">Link:</label></dt>
                    <dd><input type="text" name="link" id="" size="54" /></dd>
                </dl>
                <dl class="submit">
                    <dt></dt>
                    <dd>
                        <input type="submit" name="submit" id="submit" value="Submit" />
                    </dd>
                </dl>
            </fieldset>
        </form>
    </div>
</div>
<?php
$pagingqry = 'select * from `update` order by id desc';
$rowsPerPage = 20;
$gets = '?';

$pagelink = ADMIN_BASE_PATH . 'updates/index.php?page=';
$htmlpage = '';

include("../../includes/paging_admin.php");

$Book = $db->query($pagingqry . $limit);

$TOTAL_Book = $numrows;

if ($pagtotrow == 1)
    $pagtotrow = $_GET['page'] - 1;
else
    $pagtotrow = $_GET['page'];

if ($pagtotrow <= 0)
    $pagtotrow = 1;
?>


<h2></h2>
<h2>&nbsp;&nbsp; Updates List</h2>
<div align="center">
    <table id="rounded-corner">
        <thead>
            <tr>
                <th scope="col" class="rounded-company"></th>
                <th scope="col" class="rounded">Name</th>
                <th scope="col" class="rounded">Link</th>
                <th scope="col" class="rounded">Home Page</th>
                <th scope="col" class="rounded-q4">Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $start_sr_no = $offset + 1;
        foreach ($Book as $key => $val) {
        ?>
            <tr>
                <td><?php echo $start_sr_no++; ?></td>
                <td>
                    <?= $val['name'] ?>
                </td>
                <td>
                    &nbsp;&raquo;&nbsp;<?= $val['link'] ?>
                </td>
                <td width="60">
                    <?php
                        if ($val['home'] == 0)
                            echo '<a href="showhome.php?id=' . $val['id'] . '&action=on&page=' . $pagtotrow . '"><img src="' . ADMIN_BASE_PATH . 'images/off.png"></a>';
                        else
                            echo '<a href="showhome.php?id=' . $val['id'] . '&action=off&page=' . $pagtotrow . '"><img src="' . ADMIN_BASE_PATH . 'images/on.png"></a>';
                    ?>
                </td>
                <td width="20"><a href="deleteupdate.php?id=<?= $val['id'] ?>&page=<?= $_REQUEST['page'] ?>" class="ask"><img src="<?= ADMIN_BASE_PATH ?>images/trash.png" alt="" title="delete" border="0" /></a></td>
            </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
    </div>
<?= $PAGE_CODE ?>
<?php include $adminfolder. 'footer.php'; ?>