<?php
	//global variables
	$params['ADMINSITETITLE'] = "My Admin";
		
	$message = array(
				"0"=>"Invalid Argument!",
				"1"=>"File uploaded successfully.",
				"2"=>"Please login First.",
				"3"=>"Category added successfully.",
				"4"=>"Category deleted successfully.",
				"5"=>"Duplicate Category Found.",
				"6"=>"Please remove all subcategory first.",
				"7"=>"Only image file are allowed.",
				"8"=>"Receiving directory insuffiecient permission.",
				"9"=>"File Deleted Successfully.",
				"10"=>"File Update Successfully.",
				"11"=>"Settings Update Successfully.",
				"12"=>"Category updated successfully.",
				"13"=>"Record insert successfully."	,
				"14"=>"Record deleted successfully.",
				"15"=>"Record updated successfully.",
                                "16"=>"Username Or Passwoord Wrong.",
                                "17"=>"Can not change File Name in your hosting.",
                                "18"=>"All file move to new directory successfully."
				);


?>