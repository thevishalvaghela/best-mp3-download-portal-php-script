<?php
include 'includes/admin-config.php';
ob_start();
print '
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<url><loc>'.BASE_PATH.'</loc></url>
<url><loc>'.BASE_PATH.'special/top20.html</loc></url>
<url><loc>'.BASE_PATH.'last-added.html</loc></url>
<url><loc>'.BASE_PATH.'dis.php</loc></url>';
$cats = mysql_query("select * from category order by parentid asc") or die(mysql_error());
while ($cat = mysql_fetch_array($cats)) {
print '
<url>';
	print '<loc>'.BASE_PATH.'category/'.$cat['id'].'/'.$cat['name'].'.html</loc></url>';
}
$files = mysql_query("select * from file order by id asc") or die(mysql_error());
while ($file = mysql_fetch_array($files)) {
print '
<url>';
	print '<loc>'.BASE_PATH.'filedownload/'.$file['cid'].'/'.$file['id'].'/'.$file['name'].'.html</loc></url>';
}
print '
</urlset>';
$string = ob_get_contents();
$ff = fopen('../sitemap.xml', 'w');
fwrite($ff, $string);
fclose($ff);
ob_clean();
print 'Sitemap updated<br>Redirecting to admin panel';
?><meta http-equiv="refresh" content="3;url=<?php print ADMIN_BASE_PATH ; ?>index.php">