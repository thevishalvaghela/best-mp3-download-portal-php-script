</div>
<div class="clear"></div>
    </div> <!--end of main content-->


    <div class="footer">

        <div class="left_footer">ADMIN PANEL | Powered by <a href="http://filmymundu.com">Vishal S Baghela</a></div>
    	<div class="right_footer"></div>

    </div>

</div>
</body>
</html>