<div class="menu">
    <ul>
    	<li><a href="<?=ADMIN_BASE_PATH?>" title="Home">Admin Home</a></li>
        <li><a href="<?=ADMIN_BASE_PATH?>category/" title="Categories">Folder</a></li>
        <li><a href="<?=ADMIN_BASE_PATH?>updates/" title="updates">Updates</a></li>
        <li><a href="<?=ADMIN_BASE_PATH?>guestbook/" title="Guest Book">GuestBook</a></li>
        
        <li><a href="<?= ADMIN_BASE_PATH ?>advertisement/">Adv. Code </a> </li>
        

        <li><a href="<?=ADMIN_BASE_PATH?>setc.php" title="Set File">Recount</a></li>
        <li><a href="<?=ADMIN_BASE_PATH?>category/mp3tag.php" title="mp3 tag">Mp3 Cover</a></li>
        <li><a href="<?=BASE_PATH?>fmlogo.php" title="logo">Logo</a></li>
        <li><a href="<?= ADMIN_BASE_PATH ?>settings.php">Settings </a>
   <ul>
<li><a href="<?=ADMIN_BASE_PATH?>sitemap.php" title="sitemap">Submit Sitemap</a></li>
<li><a href="<?=ADMIN_BASE_PATH?>setch.php" title="cookies">Clear Cookies</a></li>
 </ul> </li>

    </ul>
</div>