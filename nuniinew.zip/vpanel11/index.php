<?php include 'header.php'; ?>

<?php
    $n = $db->query("select * from admin where id = 1",database::GET_ROW);
?>

<div class="center_content">  
            <h2></h2><h2 style="padding-left:20px;" allign="center"> Admin Control Pannel</h2>
<table><tr><td><div class="sidebar_box">
<div style="background: #00008B; color: #fff; text-align: center; font-size: 18px;">Main Menu</div>
<div class="sidebar_box_content">
<ul><li>
  <a href="<?=ADMIN_BASE_PATH?>category/" title="Categories">File Manager</a></li></ul>
<ul><li>
<a href="<?=ADMIN_BASE_PATH?>updates/" title="updates">Updates</a>
 </li> </ul>
<ul><li>
 <a href="<?=ADMIN_BASE_PATH?>advertisement/">Advertisement</a>
        
 </li> </ul>
<ul><li>
<a href="<?=ADMIN_BASE_PATH?>settings.php">Settings</a>
            </li> </ul>
<ul><li>
  <a href="<?=ADMIN_BASE_PATH?>category/mp3tag.php" title="Categories">MP3 Cover</a>
 </li> </ul>
<ul><li>
  <a href="<?=ADMIN_BASE_PATH?>sitemap.php" title="Categories">Generate Sitemap</a> </li> </ul>
<ul><li>
<a href="<?=ADMIN_BASE_PATH?>setc.php" title="Set File">Recount All Files</a>
 </li> </ul>
<ul><li>
 <a href="<?=ADMIN_BASE_PATH?>setch.php" title="Set File">Clear Cache</a>
 </li> </ul>
<ul><li>
 <a href="<?=BASE_PATH?>" title="Set File">Go To Site</a>
 </li> </ul>
</div></div></td>
<td class="niceform">
<center><b>
Server Details:-
</b>
<dl>
<dt><b>
Site Name:- </b></dt><dd><?=$n['sitename']?></dd></dl>
<dl>
<dt><b>
Main Url:- </b></dt><dd><?=BASE_PATH?></dd></dl>
<dl>
<dt><b>
Admin Panel :- </b></dt><dd><?=ADMIN_BASE_PATH?></dd></dl>
<dl>
<dt><b>
User Name:- </b></dt><dd><?=$n['username']?></dd></dl>
<dl>
<dt><b>
Files Last :- </b></dt><dd><?=$n['filepostfix']?></dd></dl>
<dl>
<dt><b>
Admin Email:- </b></dt><dd><?=$n['email']?></dd></dl>
<dl>
<dt><b>
Total Files:- </b></dt><dd> <?php $folder = '../upload_file';
    $folder_file = get_files($folder,true);
$total_file = count($folder_file);
echo $total_file; 
?> </dd></dl>
<dl>
<dt><b>
 Email:- </b></dt><dd><?=$n['email']?></dd></dl>
<dl>
<dt><b>
Support Persion:- </b></dt><dd><a href="http://facebook.com/vishalsbaghelaooh/" title="Vishal S Baghela"><span style="color: red;"><b>Vishal S Baghela</b> </span></a></dd></dl>
<dl>
<dt><b>
Support Email:- </b></dt><dd>vishalsbaghela@gmail.com</dd></dl>
<dl>
<dt><b>
Copyright:-</b>
</dt>
<dd>
<span style="color: red;">FilmyMundu.Com All Rights Reserved </span>
</dd></dl></center>
</td>
</table>
</div>
 

<?php include $adminfolder.'footer.php'; ?>