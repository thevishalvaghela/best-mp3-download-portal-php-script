<?php session_start();
        include 'includes/config.php';
	include 'header.php';

        function _generateRandom($length=6)
        {
            $_rand_src = array(
                array(48,57) //digits
                , array(97,122) //lowercase chars
        //        , array(65,90) //uppercase chars
            );
            srand ((double) microtime() * 1000000);
            $random_string = "";
            for($i=0;$i<$length;$i++){
                $i1=rand(0,sizeof($_rand_src)-1);
                $random_string .= chr(rand($_rand_src[$i1][0],$_rand_src[$i1][1]));
            }
            return $random_string;
        }

	$pagingqry = 'select * from `guest_book` order by id desc';
	$rowsPerPage=10;
	$gets='?';
	
	$pagelink = BASE_PATH.'guestbook/';
	//echo $sort;
	$htmlpage = '/more.html';
	include("includes/paging.php");
	
	$GUEST = $db->query($pagingqry.$limit);			
	$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

?>
<!-- chintanhingrajiya@gmail.com :: Display Random files -->
<script src="<?=BASE_PATH?>js/validation.js"></script>
<script language="javascript" >
	var compulsory = new Array('name','mobile','mail','message');
	var dispError = new Array('name !','mobile !','mail !','message !');
</script>

<div class="categoryPath">
	<h1>Welcome to our Guest-Book</h1>
</div>
<div style="width:100%">
	<?=$CurrentMessage?>
</div>
<div class="guestBook">
	<h3>Add Entry to Guest Book!</h3>

	<form name="form" action="<?=BASE_PATH?>guestAdd.php" method="post" onsubmit="return chkfrm(compulsory,dispError,this)">
	<p>Your Name<br />
		<input class="textbox" type="text" name="name" /><br />
		Your 10 Digit Mobile No<br />
		<input class="textbox" type="text" name="mobile" maxlength="10" /><br />
		Your Real Email Id<br />
		<input class="textbox" type="text" name="email" /><br />
		Message<br />
		<textarea class="textbox" name="message"></textarea><br />
                Security Code<br />
                <img src="<?=BASE_PATH?>captcha.php" alt="captcha image"><br />
                <input type="text" name="captcha" size="3" maxlength="3"><br />
                (Enter 3 black symbols)<br />
		<input class="button" type="submit" name="Gsubmit" value="Add Entry" onClick="return checkForm(Gform)" />
		<input class="button" type="reset" name="reset" value="Reset">
	</p>
	</form>
</div>

	<div class='updates' align="left">
		<h2>GuestBook Message</h2>
		<?php
			$tot_file = count($GUEST);
			for($i=0;$i<$tot_file;$i++)
			{
            	echo '<div align="left">Time: '.fromSqlDate($GUEST[$i]['date'],'d-M-Y h:i:s').'</div>';
            	echo '<div align="left">IP: '.$GUEST[$i]['ip'].'</div>';
	            echo '<div align="left">Name: '.$GUEST[$i]['name'].'</div>';
    	        echo '<div align="left">Message: '.$GUEST[$i]['message'].'</div>';
				echo '<div style="background-color:#39F"></div>';
			}
		?>
	</div>
<center>
<?=$PAGE_CODE?>
</center>
<div class="path">
	<?=$PATH?>
</div>
				