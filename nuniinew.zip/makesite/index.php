<?php
print '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta forua="true" http-equiv="Cache-Control" content="max-age=0"/>
<title>Create Your Own PHP Wapsite </title>';
echo '<link rel="shortcut icon" href="/image/icon.ico" />';
echo '<link href="/css/styles.css" rel="stylesheet" style="text/css"></head><body>';
print '<div class="logo"><center><img src="/image/nunihostlogo.png" width="250" height="80" alt="logo"/></center></div><br/>';
print '<h2><center><b>Create Your Own PHP WapSite</b></center></h2>';

print '<center><div class="search"><b>We Can Create Your Own Download site like This . With Many Many extra facility. </b></div></center>
<br/><b>
<div class="catRow">1. One Free Domain .Com or .In For One Year. </div>

<div class="catRow">2. One Month Free<font color="green"> Hosting with unlimited bandwitch &amp; 20GB Disk space From NuniHost.Com</font></div>

<div class="catRow">3. Auto Mp3 Tag Edit , Auto Mp3 Image Tag, Online Mp3 Player .</div>

<div class="catRow">4. Facebook Comment Box, Whatsup Share , Facebook Share In All Pages.</div>

<div class="catRow">5. Auto Add Your Site Name In Last Of All Files .</div>

<div class="catRow">6. Mp3 Thumb Preview, Image Preview With WaterMark .</div>

<div class="catRow">7. Sitemap Generator IN Admin Panel.</div>

<div class="catRow">8. Admin Panel Also Worked In Android Phones .</div>

<div class="catRow">9. Secure And Fast Admin Panel. .</div>

<div class="catRow">10. We Provide Your Site With Admin Panel & Cpanel Both.</div>

<div class="catRow">11. We Will Design Your Site with Your Choice as You Want any Type Design.</div>

<div class="catRow">12. 100% Site Will Be Running,No Server Down WIll be There</div>

<div class="catRow">13. We Provides 24 Hours Customer Support .</div>

<div class="catRow">14. You Can Use Advertising ads Code In Site For Earnings.</div>
<br/>

<div class="catRow"><font color="blue">About Devlopers  :- </font></div></b>
<div class="wap"><b><i>Hosting Website :-  <a href="http://nunihost.com"> <font color="RED"> NuniHost.com</font> </a>
    <br/>  Facebook :- <a href="https://www.facebook.com/vishalsbaghelaooh"> <font color="RED"> Vishal S Bahela </font> </a>
    <br/> Contact No:- +91 ********** (    )
    <br/> Contact No:- +91 9828181665 (Vishal S Baghela)
       <br/></div>';
echo '<div class="search"><b><font color="#ffffff"><a class="siteLink" href="index.php">Home</a></font></b></div>';
echo '</body></html>';
?>