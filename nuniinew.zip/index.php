﻿<?php
	include 'includes/config.php';
	include 'header.php';
       

	$check = '';
   $TOTAL_FILE = 0;
   $rowsPerPage=15;
	
	$PATH = '';

	if($parentid != 0)
	{
		//from 41
		$folddetail = $db->query("select * from category where id = ".$parentid, database::GET_ROW);
		$seq =  $folddetail['pathc'];//$db->query("select pathc from category where id = ". $parentid, database::GET_FIELD);
		$PATH = '» <a href="'.BASE_PATH.'">Home</a> ';
		$PATH .= $seq;

	}
	
	if($parentid == 0)
	{
		$update_list = $db->query('select * from `update` where home = 1 order by id desc limit 0,20');
		?>
<div class="updates">
<h2>Latest Updates</h2></div>
			<div align="left" class="updates">
				<?php
foreach($update_list as $field => $value)
{
?>
<div align="left"><?=$value['name']?><?php if($value['link'] != '') { ?>
<a href="<?=$value['link']?>">[Click Here]</a ><?php } ?></div>
<?php
} ?>
				<div>
					<a href="<?=BASE_PATH?>updates/update.html" class="updateRow">[More Updates...]</a>
				</div>
			</div>

		<?php
		$check = 'now';
	}
	else
	{
		
		$getfilecat =  $folddetail['subcate'];//$db->query('select subcate from category where id = '.$parentid, database::GET_FIELD);
		
		// get category detail
		
		$FOLDER = $folddetail['folder'];
		$DES =  $folddetail['des'];
		$NAME = $folddetail['name'];
		$THUMB = $folddetail['thumb'];
		?>
			<div class="description">
				<center>
					<?php include 'j'.$agent_ext?>
				</center>


			</div>		
		<?php

		if($getfilecat == 0)
		{
			// check this folder have a file or not
			$checkfileor = $folddetail['totalitem'];// $db->query('select totalitem from category where id = '.$parentid, database::GET_FIELD);
			if($checkfileor != 0)
			{
				$TOTAL_FILE = 1;
				$sort = $_GET['sort'];
				
				if($sort == 'download')
					$getfilelist = 'select * from file where cid = '.$parentid.' order by download desc';
				elseif($sort == 'az')
					$getfilelist = 'select * from file where cid = '.$parentid.' order by name';
				elseif($sort == 'recent')
					$getfilelist = 'select * from file where cid = '.$parentid.' order by id desc';
				else
					$getfilelist = 'select * from file where cid = '.$parentid.' order by kram desc';
				
				$rowsPerPage=8;
				$pagingqry = $getfilelist;
				$gets='?';
				
				if($sort == '')
					$sort = 'category';
	
				$pagelink = BASE_PATH.'category/'.$sort.'/'.$parentid.'/';
				//echo $sort;
				
				$htmlpage = '/'.$nname.'.html';
				include("includes/paging.php");
				
				$FILE = $db->query($pagingqry.$limit);
				?>
<hr>				
				<h2>

					<?php 
						if($nname != '')
							echo $nname;
						else
							echo 'Download Menu';
					?>
				</h2>
<center>
				



<br/>


<center><div style="border:1px solid #bbb; padding:2px; border-radius:10px; padding:3px 1px; display:table-cell;"><?php include 'fthumb.php' ?></div></center>

		
<center>
				 <div class="pgn">
					Sort By : <small>
<a href="<?=BASE_PATH?>Categorylist/download/<?=ToLink($parentid);?>/<?=ToLink($PAGE);?>/<?=ToLink($NAME);?>.html" class="dow_2">By Download</a>
-
<a href="<?=BASE_PATH?>Categorylist/az/<?=ToLink($parentid);?>/<?=ToLink($PAGE);?>/<?=ToLink($NAME);?>.html" class="dow_2">A To Z</a>
-
<a href="<?=BASE_PATH?>Categorylist/recent/<?=ToLink($parentid);?>/<?=ToLink($PAGE);?>/<?=ToLink($NAME);?>.html" class="dow_2">Recent Added</a>
 
					</small>
				</div> 					
</center>
				<table cellspacing="0">
					<tbody>
						<tr>
							<td colspan="2">
								<?php include 'h'.$agent_ext?>
							</td>
						</tr>
			<!---//Developed By Vishal S Baghela--->			<?php
							$l = 1;
							$file_tot = count($FILE);
							for($i=0;$i<$file_tot;$i++)
							{
								if($l==1)
								{
									$l++;
									$class = 'fl odd';
								}
								else
								{
									$l=1;
									$class='fl even';
								}
					
								?>
									<tr class="<?=$class?>">
										<td class="tblimg">
											<?php
												if($FILE[$i]['thumbext'] == '')
												{
													if($THUMB == '')
														echo '<img src="'.BASE_PATH.'image/'.$FILE[$i]['ext'].'.png" alt="'.$FILE[$i]['name'].'" width="70" height="70" class="border_4"> ';
													else
														echo '<img src="'.BASE_PATH.'folderthumb/'.$THUMB.'" alt="'.$FILE[$i]['name'].'" width="70" height="70" class="border_4"> ';
												}
												else
													echo '<img src="'.BASE_PATH.$FOLDER.'thumb-'.$FILE[$i]['dname'].'.'.$FILE[$i]['thumbext'].'" width="70" height="70" alt="'.$FILE[$i]['name'].'" class="border_4"> ';
											?>	
										</td>
										<td align="left">
											<a class="new_link" href="<?=BASE_PATH?>filedownload/<?=$parentid?>/<?=$FILE[$i]['id']?>/<?=$FILE[$i]['name']?>.html"><b><?=$FILE[$i]['name']?>.<?=$FILE[$i]['ext']?></b><br/> 
											<span>[<?= getSize($FILE[$i]['size']) ?>]<br/><?= $FILE[$i]['download'] ?> Downloads</span></a>
										</td>
									</tr>
								<?php
							}
						?>
						<tr>
							<td colspan="2">
								<?php include 'i'.$agent_ext?>
							</td>
						</tr>
					</tbody>
				</table>
				<?php	
			}
		}
		else
			$check = 'now';
	}
	
if($check == 'now' )
{

	echo '<!-- NuniHost.Com :: Display category list -->';
	?>
	<center>
		<?=$DES?>
	</center>
	<div id='catLst' align="left">
		<h2>
			<?php 
				if($nname != '')
					echo $nname;
				else
					echo 'Select Categories';
			?>
		</h2>
		<?php 
			if($LOGO == '')
				include 'h'.$agent_ext;

			// this will only for home page
			// cat
			
			//$gettotcat = 'select count(id) from category';
			//$params['TOTCATE'] = $conn->singleval($gettotcat);
			//file
			//$gettotfile = 'select count(id) from file';
			//$params['TOTFILE'] = $conn->singleval($gettotfile);
			//mp4
			//$gettotmp4 = 'select count(id) from file where ext = "mp4"';
			//$params['TOTMP4'] = $conn->singleval($gettotmp4);
			//3gp
			//$gettot3gp = 'select count(id) from file where ext = "3gp"';
			//$params['TOT3GP'] = $conn->singleval($gettot3gp);
		
			$rowsPerPage=20;
			$pagingqry = "select * from category where parentid = ".$parentid. ' and active = 0 order by kram desc';
			
			$gets='?';
	
			$pagelink = BASE_PATH.'category/'.$parentid.'/';
	
			$htmlpage = '/'.$_GET['ht'].'.html';
			include("includes/paging.php");
			
			$CATEGORY = $db->query($pagingqry.$limit);
			
			
		?> 
		<div class='contex' align="left">
			<?php 
				$l = 1;
				$totcat = count($CATEGORY);
				for($i = 0 ; $i < $totcat ; $i++)
				{
					if($l==1)
					{
						$l++;
						$class = 'catRow';
					}
					else
					{
						$l=1;
						$class='catRow';
					}
				
					echo '<div class="'.$class.'">';
						if($CATEGORY[$i]['thumb'] == '')
						{
							if($CATEGORY[$i]['totalitem'] != 0)
								echo "";
							else
								echo "";
						}
						else

echo "  ";
echo " <a href='".BASE_PATH."category/".ToLink($CATEGORY[$i]['id'])."/".ToLink($CATEGORY[$i]['name']).".html' class='new_link'> ";		
echo $CATEGORY[$i]['name'] ;


								if($CATEGORY[$i] [ 'totalitem' ] != 0) 
								{
									//if($CATEGORY[$i]['subcate'] == 0)
										echo ' ('. $CATEGORY[$i]  [ 'totalitem' ] . ') ';
								}
								
						echo '</a>';
					echo '</div>';
				}
											
				if($LOGO != '')
				{
					echo '<div class="advertisement">';
						include 'c'.$agent_ext;
					echo '</div>';
				}
				else
					include 'i'.$agent_ext;
                   
			?>
		</div>
	</div>
	<?
}
?>
<center>
	<?=$PAGE_CODE?>
</center>
<?php
if($TOTAL_FILE != 0)
{
	echo '<center>';
	include 'k'.$agent_ext;
	echo '</center>';
}
?>
</center>
 <?php
if($parentid != 0)
{
?>
<div class="path"><?=$PATH?></div>
 <?php
 }
 ?>
 
<?php
	include 'footer.php';
?>