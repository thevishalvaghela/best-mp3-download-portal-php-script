<?php
/*
// seconds, minutes, hours, days
$expires = 60*60*24*14;
header("Pragma: private");
header("Cache-Control: maxage=".$expires);
header('Expires: ' . gmdate('D, d M Y H:i:s', time()+$expires) . ' GMT');
header('Content-type: text/html; charset=utf-8'); */
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=$nname?> <?=SITENAME?> - Mp3 Songs BollyWood Videos,Bollywood Album Mp3 Song, Movie Song 2016,Latest Mp3 Song  Hindi Songs , Holi Songs , Album Videos ,Free Mobile Ringtones|
 MP3 Songs | Romantic Hindi Music MP3 Songs download 
</title>

<link rel="shortcut icon" href="<?=BASE_PATH?>image/icon.ico" />
<meta name="description" content="<?=$nname?> -Free Bollywood Mp3 Songs, DJ Remix Songs, Instrumental Songs, TV Serial Songs, Devotional Songs download video 3gp and mp4 for mobile download video 3gp and mp4 for mobile" />
<meta name="keywords" content="<?=$nname?> Free Bollywood Songs, DJ Remix Songs, Instrumental Songs, TV Serial Songs, Devotional Songs movie, music, video ,3gp, mp4, movie, music, video" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="language" content="en" />
<meta name="revisit-after" content="2 days">
<meta name="robots" content="all">
<meta name="Author" content="NuniHost.Com">

<link rel="stylesheet" href="<?=BASE_PATH?>css/style.css" type="text/css" />
<link rel="stylesheet" href="<?=BASE_PATH?>css/paging.css" type="text/css" />
</head><body>
<div class="logo"><a href="<?=BASE_PATH?>"><img src="<?=BASE_PATH?>image/nunihostlogo.png" alt="logo" width="300" height="80" /></a> </div>

<?=$LOGO?>




	<center><div class="bkmk"><a href="#"><b>Click Here To BookMark Us !</b></a></div></center>
	<div align="center"><div class="row"  style="background-color: #FFFFFF; color: #383838; padding: 1px; margin-top: 2px; margin-left: 3px; margin-right: 3px;"> 
	<a href="https://www.facebook.com/nunihost.com"><img src="/image/facebookpc.png" alt="" /></a>
	
	<script language="javascript">
document. write('<a href="whatsapp://send?text='+document.title+' @ '+document.URL+'"> <img src="/image/whatsapp.png" width="" height=""/> </a>')</script>
 
 <a href="javascript:void(window.open('https://www.facebook.com/sharer/sharer.php?u=' + location.href, 'sharer', 'width=626,height=436,toolbar=0,status=0'));" class="fb-share-button fb-share-button-22">
<span><img src="/image/sharebig.gif" width="" /></span></a>
 
 </div></div>
	
	
	






<center>
<?php
if(strstr(strtolower($agent_c),'windows'))
$agent_ext = '.pdv';
else
$agent_ext = '.adv';

if($LOGO != '')
include 'a'.$agent_ext;
else
include 'a'.$agent_ext;
?>
</center>
<div class='search'>
<form method='get' action='<?=BASE_PATH?>search.php'>
Search File :
<input id='search' size='20' type='text' name='search' value="<?=$search?>">
<select name="type">
<option value='' <?php if($type == 'all') echo 'selected'; ?>>All</option>
<option value='3gp' <?php if($type == '3gp') echo 'selected'; ?> >3gp</option>
<option value='jpg' <?php if($type == 'jpg') echo 'selected'; ?>>jpg</option>
<option value='gif' <?php if($type == 'gif') echo 'selected'; ?>>gif</option>
<option value='mp3' <?php if($type == 'mp3') echo 'selected'; ?>>mp3</option>
<option value='avi' <?php if($type == 'avi') echo 'selected'; ?>>avi</option>
<option value='mp4' <?php if($type == 'mp4') echo 'selected'; ?>>mp4</option>
<option value='jar' <?php if($type == 'jar') echo 'selected'; ?>>jar</option>
<option value='sis' <?php if($type == 'sis') echo 'selected'; ?>>sis</option>
<option value='sisx' <?php if($type == 'sisx') echo 'selected'; ?>>sisx</option>
<option value='nth' <?php if($type == 'nth') echo 'selected'; ?>>nth</option>
<option value='exe' <?php if($type == 'exe') echo 'selected'; ?>>exe</option>
<option value='pdf' <?php if($type == 'pdf') echo 'selected'; ?>>pdf</option>
</select>
<input value='Search' type='submit' name='searchnow'>
</form>
</div>

<?php if($parentid == 0) {include "random.php"; } ?>