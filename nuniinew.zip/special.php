<?php
include 'includes/config.php';
include 'header.php';

if($_GET['do'] == 'top20')
$wh = ' where category.id = file.cid order by file.download desc ';
if($_GET['do'] == 'last-added')
$wh = ' where category.id = file.cid order by file.id desc ';

$special = 'select file.id,file.name,file.dname,file.ext,file.cid,file.thumbext,file.size,file.download,file.newtag,category.folder,category.thumb from `file` , category '.$wh;
$rowsPerPage=21;
$pagingpassid = 'file.id';
$pagingqry = $special;
$gets='?';

$pagelink = BASE_PATH.'special/'.$_GET['do'].'/';
//echo $sort;

$htmlpage = $nname.'.html';
include("includes/paging.php");

$do = $_GET['do'];

$SPECIAL = $db->query($pagingqry.$limit);
$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- :: Display Random files -->';
?>
<table cellspacing="0">
<tbody>
<tr>
<td align="center" colspan="2">
<h3>
<?php
if($do == 'top20')
echo 'Top 20';
elseif($do == 'last-added')
echo 'Recently Added';
?>
</h3>
</td>
</tr>
<?php
$l = 1;
$file_tot = count($SPECIAL);
for($i=0;$i<$file_tot;$i++)
{
if($l==1)
{
$l++;
$class = 'fl odd';
}
else
{
$l=1;
$class='fl even';
}

?>
<tr class="<?=$class?>">
<td class="tblimg">
<?php include 'spe_preview.php'; ?>
</td>
<td align="left">
<a class="new_link" href="<?=BASE_PATH?>filedownload/<?=$SPECIAL[$i]['cid']?>/<?=$SPECIAL[$i]['id']?>/<?=$SPECIAL[$i]['name']?>.html"><b><?=$SPECIAL[$i]['name']?>.<?=$SPECIAL[$i]['ext']?></b><br/>
<span class="text11">[<?=getSize($SPECIAL[$i]['size'])?> ] &nbsp; | &nbsp; <?=$SPECIAL[$i]['download']?> Downloads</span></a>
</td>
</tr>
<?php
}	?>
</tbody>
</table>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
$parentid = 1;
include 'footer.php';
?>
