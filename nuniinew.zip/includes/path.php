<?php define("BASE_PATH","http://modiwap.tk/");
define("SITENAME","BhojpuriyaSongs.Com"); ?>