<?php $db_host = "localhost";
$db_user = "xcyber_modi";
$db_pass = "QW12345";
$db_name = "xcyber_modi";
// Calling the object with a database selected
$db = new database($db_host,$db_user,$db_pass,$db_name); ?>