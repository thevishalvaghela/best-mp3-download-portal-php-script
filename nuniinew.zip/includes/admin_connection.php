<?php
require_once 'includes/CacheHandler.Class.php';
require_once 'includes/admin.class.database.php'; include 'includes/db_details.php';
?>
