<?php
##########################################
// Filmymundu Inc. //
// WwW.Filmymundu.com//
// vishalsbaghela@gmail.com//
// Best Offer For New Buyer/Friends contact now // 
 
##########################################
$agent_c = $_SERVER['HTTP_USER_AGENT'];

$rootDir = dirname(dirname(__FILE__));
set_include_path($rootDir . PATH_SEPARATOR . get_include_path());

// if not get error than take screen shot ;)
//include("class.URI_Cache.php");
//$cache = new URI_Cache(1100);
require_once('includes/language.php');
require_once('includes/function.php');
require_once('includes/connection.php');
require_once('includes/path.php');//$db->disconnect();
//for error message
if ($_REQUEST['errid'] != "" && is_numeric($_REQUEST['errid'])) {
if (count($message) < $_REQUEST['errid']) {
$msg = $message[0];
} else {
$msg = $message[$_REQUEST['errid']];
}

$CurrentMessage = "<span class='error'>" . $msg . "</span><br>";
}
//print_r($_REQUEST);
$nname = $_GET['ht'];

if ($_GET['pid'] != '')
$parentid = $_GET['pid'];
else
$parentid = 0;


if (!is_numeric($parentid)) {
echo "Please not try to be claver. Please do not edit url manually";
exit;
}


// get title
if ($parentid != '' && $parentid > 0) {
$folqtt = $db->query("select clink from category where id = " . $_REQUEST['pid'], database::GET_FIELD);
$NTITLE = str_replace('/', ' > ', $folqtt);
}
//$params['HEAD_TITLE'] = $headset['title'];
define("SITETITLE", $headset['title']);
define("SITENAME",$headset['sitename']);
define("POSTFIX", $headset['filepostfix']);
define("THUMB_W", $headset['dthumbw']);
define("THUMB_H", $headset['dthumbh']);

?>


