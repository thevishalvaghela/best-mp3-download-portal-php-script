<?php define("SITETITLE","Full2MoB.TK");
define("ADMINTITLE","Admin Panel | By Sahil");


$message = array(
"0"=>"Invalid Argument.",
"1"=>"Please Login first.",
"2"=>"Username or password wrong.",
"3"=>"Please Enter Valid Email.",
"4"=>"CAPTHCA is not valid;"

);

//for search
//$commonwords = array('is','this','a','in','on','for','of');

//read this carefully
//last element not have comma(,)




?>
