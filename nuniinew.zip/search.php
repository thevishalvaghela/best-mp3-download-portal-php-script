<?php
include 'includes/config.php';

$type = $_GET['type'];
$search = $_GET['search'];

include 'header.php';
if ($_GET['type'] != '')
$seq = "select *  from category as c,file as f where f.name like '%" . $_GET['search'] . "%' and f.ext = '" . $_GET['type'] . "' and f.cid = c.id";
else
$seq = "select * from category as c,file as f where f.name like '%" . $_GET['search'] . "%' and f.cid = c.id";

$rowsPerPage = 5;
$pagingqry = $seq;
$gets = '?';

if ($sort == '')
$sort = 'category';

$pagelink = BASE_PATH . 'search.php?search=' . $_GET['search'] . '&type=' . $_GET['type'] . '&page=';
//echo $sort;

$htmlpage = '';
$pagingpassid = 'f.id';
include("includes/paging.php");

$LIST = $db->query($pagingqry . $limit,0,'no');

$LISTTOTAL = $numrows;


$PATH = '&raquo;&nbsp;<a href="' . BASE_PATH . '">Home</a>&nbsp;';
?>
<table cellspacing="0">
<tbody>
<?php
if ($LISTTOTAL != 0) {
echo '<!-- NuniHost.Com :: Display category list -->';
$l = 1;
$file_tot = count($LIST);
for ($i = 0; $i < $file_tot; $i++) {
if ($l == 1) {
$l++;
$class = 'odd';
} else {
$l = 1;
$class = 'even';
}
?>
<tr class="<?= $class ?>">
<td class="tblimg">
<?php
if ($LIST[$i]['thumbext'] == '')
echo '<img src="' . BASE_PATH . 'image/' . $LIST[$i]['ext'] . '.png" alt="' . $LIST[$i]['name'] . '" class="border_4"> ';
else
echo '<img src="' . BASE_PATH . $LIST[$i]['folder'] . 'thumb-' . $LIST[$i]['dname'] . '.' . $LIST[$i]['thumbext'] . '" alt="' . $LIST[$i]['name'] . '" class="border_4">';
?>
</td>
<td align="left">
<a class="new_link" href="<?= BASE_PATH ?>filedownload/<?= $LIST[$i]['cid'] ?>/<?= $LIST[$i]['id'] ?>/<?= $LIST[$i]['name'] ?>.html"><?= $LIST[$i]['name'] ?>.<?= $LIST[$i]['ext'] ?></a>
<br>
<span class="text11">[<?= getsize($LIST[$i]['size']) ?> ] &nbsp; | &nbsp; <?= $LIST[$i]['download'] ?> Downloads</span>
</td>
</tr>
<?php
}
}
else {
?>
<tr class="<?= $class ?>">
<td class="tblimg">
Sorry No match found for <span class="error"><?= $search ?></span> in <span class="error"><?= $type ?></span> files
</td>
</tr>
<?php } ?>
</tbody>
</table>

<?php
if ($LISTTOTAL != 0)
echo $PAGE_CODE;
?>
<div class="path">
<?= $PATH ?>
</div>

<?php
include 'footer.php';
?>
