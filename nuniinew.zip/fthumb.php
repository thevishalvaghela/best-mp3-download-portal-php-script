<?php
    $z = "select * from category where id = ".$parentid;
    $CATGORY = $db->query($z,  database::GET_ROW);
$FTHUMB = $CATGORY['thumb'];

if($FTHUMB == '')
echo '';
else
echo '<div class="list">
<p class="tCenter showimage">
<img src="'.BASE_PATH.'folderthumb/'.$FTHUMB.'" alt="'.$CATGORY['name'].'" width="130px" height="150px" class="border_4">
</p>
</div> ';
?>
