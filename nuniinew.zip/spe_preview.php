<?php
$spe_info = ''.$SPECIAL[$i]['folder'].''.$SPECIAL[$i]['name'].'.'.$SPECIAL[$i]['ext'].'';
if ($SPECIAL[$i]['ext'] == nth OR $SPECIAL[$i]['ext'] == thm) {  echo '<img src="/theme.php?file='.$spe_info.'" width="70" height="70" alt="'.$SPECIAL[$i]['name'].'" class="border_4">'; } elseif ($SPECIAL[$i]['ext'] == jar) {  echo '<img src="/jar.php?file='.$spe_info.'" width="70" height="70" alt="'.$SPECIAL[$i]['name'].'" class="border_4">'; }
elseif($SPECIAL[$i]['thumbext'] == '')
{
if($SPECIAL[$i]['thumb'] == '')
echo '<img src="'.BASE_PATH.'image/'.$SPECIAL[$i]['ext'].'.png" alt="'.$SPECIAL[$i]['name'].'" width="70" height="70" class="border_4"> ';
else
echo '<img src="'.BASE_PATH.'folderthumb/'.$SPECIAL[$i]['thumb'].'" alt="'.$SPECIAL[$i]['name'].'" width="70" height="70" class="border_4"> ';
}else
echo '<img src="'.BASE_PATH.$SPECIAL[$i]['folder'].'thumb-'.$SPECIAL[$i]['dname'].'.'.$SPECIAL[$i]['thumbext'].'" width="70" height="70" alt="'.$SPECIAL[$i]['name'].'" class="border_4"> ';
?>
