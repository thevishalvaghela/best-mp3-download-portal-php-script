<?php
include 'includes/config.php';
include 'header.php';

$pagingqry = 'select * from `update` order by id desc';
$rowsPerPage=10;
$gets='?';
$pagelink = BASE_PATH.'updates/';
//echo $sort;
$htmlpage = '/more.html';
include("includes/paging.php");

$UPDATE = $db->query($pagingqry.$limit);

$PATH = '&raquo;&nbsp;<a href="'.BASE_PATH.'">Home</a>&nbsp;';

echo '<!-- WapkaHost.Com :: Display Random files -->';
?>
<div class='updates' align="left">
<h2>Latest Updates</h2>
<?php
$file_tot = count($UPDATE);
for($i=0;$i<$file_tot;$i++)
{
echo '<div align="left">';
echo '<strong>'.fromSqlDate($UPDATE[$i]['date'],'d-M').' :</strong> '.$UPDATE[$i]['name'].'&nbsp;';
if($UPDATE[$i]['link'] != '')
echo '<a href="'.$UPDATE[$i]['link'].'" class="new2_text">[Click Here]</a>';
echo '</div>';
}
?>
</div>
<center>
<?=$PAGE_CODE?>
</center>

<div class="path">
<?=$PATH?>
</div>

<?php
include 'footer.php';
?>
