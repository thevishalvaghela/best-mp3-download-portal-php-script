<?php
$file_info = ''.$FOLDER.''.$getfile['name'].'.'.$getfile['ext'].'';
if ($getfile['ext'] == nth OR $getfile['ext'] == thm) {  echo '<img src="/theme.php?file='.$file_info.'" width="70" height="70" alt="'.$getfile['name'].'" class="border_4">'; } elseif ($getfile['ext'] == jar) {  echo '<img src="/jar.php?file='.$file_info.'" width="70" height="70" alt="'.$getfile['name'].'" class="border_4">'; }
elseif ($getfile['thumbext'] == '')
{
if($THUMB == '')
echo '<img src="'.BASE_PATH.'image/'.$getfile['ext'].'.png" alt="'.$getfile['name'].'" width="70" height="70" class="border_4"> ';
else
echo '<img src="'.BASE_PATH.'folderthumb/'.$THUMB.'" alt="'.$getfile['name'].'" width="70" height="70" class="border_4">';
}
else {
echo '<img src="'.BASE_PATH.$FOLDER.'thumb-'.$getfile['dname'].'.'.$getfile['thumbext'].'" width="70" height="70" alt="'.$getfile['name'].'" class="border_4">'; }
